const territories = [
  {
    name:"Pacífico", tone:"#244b4f", accent:"#79b4a7", symbol:"≈", 
    text:"Ríos, bosques, selvas, minería y pueblos étnicos forman parte de un territorio donde la relación con la tierra y los recursos resulta indispensable para comprender las dinámicas del conflicto.",
    url:"https://www.comisiondelaverdad.co/pacifico-capitulo-1",
    video:{title:"El Carmen de Atrato",desc:"Una puerta audiovisual para acercarte a un municipio chocoano y observar cómo la guerra transforma vidas, memorias y relaciones con el territorio.",url:"https://www.comisiondelaverdad.co/sites/default/files/2023-02/rv_carmen_atrato_master_web%20%28720p%29.mp4"}
  },
  {
    name:"Valle del Cauca y norte del Cauca", tone:"#405447", accent:"#c0c66f", symbol:"✣",
    text:"Territorios ancestrales afro e indígenas se cruzan con tierras productivas, economías ilegales, propiedad y dinámicas contrainsurgentes. La mirada territorial ayuda a reconocer relaciones que una explicación monocausal dejaría por fuera.",
    url:"https://www.comisiondelaverdad.co/valle-capitulo-1"
  },
  {
    name:"Nariño y sur del Cauca", tone:"#4c4b49", accent:"#c78d69", symbol:"▲",
    text:"Volcanes, Macizo Colombiano y territorios ancestrales forman el escenario de procesos de despojo, disputas por la tierra, economías ilegales y violencias ejercidas por distintos actores.",
    url:"https://www.comisiondelaverdad.co/narino-capitulo-1"
  },
  {
    name:"Amazonía", tone:"#274a3a", accent:"#86a85f", symbol:"♣",
    text:"La historia territorial no comienza con la llegada de los actores armados. Explotación de recursos, colonización y violencias contra pueblos originarios forman capas históricas necesarias para comprender la región.",
    url:"https://www.comisiondelaverdad.co/amazonia-capitulo-0",
    video:{title:"Mitú",desc:"Una pieza para acercarse a la toma de Mitú y a sus impactos en un territorio con fuerte presencia indígena, escuchando la guerra desde el Vaupés.",url:"https://www.comisiondelaverdad.co/sites/default/files/2023-02/rv_mitu_master_web%20%28720p%29.mp4"}
  },
  {
    name:"Orinoquía", tone:"#52604a", accent:"#d0c46b", symbol:"≋",
    text:"Colonización, pueblos indígenas y relaciones históricas con la Colombia central permiten observar cómo se configuraron y transformaron dinámicas sociales, políticas y armadas.",
    url:"https://www.comisiondelaverdad.co/orinoquia-capitulo-1"
  },
  {
    name:"Frontera nororiental", tone:"#334c55", accent:"#e1a15d", symbol:"⌖",
    text:"Petróleo, frontera con Venezuela, cordillera y Llanos se entrelazan en una región cuya condición fronteriza es clave para comprender dinámicas económicas, políticas, sociales y armadas.",
    url:"https://www.comisiondelaverdad.co/frontera-capitulo-1",
    video:{title:"Fronteras",desc:"¿Qué cambia cuando una frontera deja de mirarse como periferia? Esta pieza invita a cuestionar estigmas y a escuchar cómo sus habitantes nombran el territorio.",url:"https://www.comisiondelaverdad.co/sites/default/files/2023-02/rv_frontera_master_web%20%28720p%29.mp4"}
  },
  {
    name:"Centro", tone:"#514941", accent:"#caa26b", symbol:"⌂",
    text:"En la región central se aglutinaron hechos decisivos de la historia de la guerra y de la paz desde el segundo tercio del siglo XX, con efectos prolongados sobre distintas generaciones campesinas.",
    url:"https://www.comisiondelaverdad.co/centro-capitulo-1",
    video:{title:"Roncesvalles",desc:"Un municipio recuerda una toma guerrillera que marcó la vida local. La pieza permite observar cómo un hecho armado permanece y se reelabora en la memoria de una comunidad.",url:"https://www.comisiondelaverdad.co/sites/default/files/2023-02/rv_roncesvalles_master_web%20%28720p%29.mp4"}
  },
  {
    name:"Dinámicas urbanas", tone:"#38434c", accent:"#8aa8b3", symbol:"▥",
    text:"La guerra tampoco fue únicamente rural. Crecimiento de las ciudades, población universitaria, protesta y expresiones armadas urbanas muestran otras formas del conflicto y sus conexiones territoriales.",
    url:"https://www.comisiondelaverdad.co/dinamicas-capitulo-1"
  },
  {
    name:"Magdalena Medio y Santander", tone:"#3c4c43", accent:"#9ab6a3", symbol:"⌇",
    text:"Altos niveles de violencia conviven con una historia significativa de organización campesina, obrera y estudiantil. Mirar ambas dimensiones evita reducir el territorio únicamente a la victimización.",
    url:"https://www.comisiondelaverdad.co/magdalena-medio-capitulo-1"
  },
  {
    name:"Caribe", tone:"#3d5960", accent:"#e4b765", symbol:"☼",
    text:"Riqueza natural y cultural y desigualdades persistentes forman parte de un contexto regional conectado con disputas por tierra, poder político y dinámicas armadas.",
    url:"https://www.comisiondelaverdad.co/caribe-capitulo-1",
    video:{title:"Caribe",desc:"Una pieza que parte de la geografía y abre preguntas sobre tierra, poder, violencia y responsabilidades en el Caribe colombiano.",url:"https://www.comisiondelaverdad.co/sites/default/files/2023-02/rv_caribe_master_web%20%28720p%29.mp4"}
  },
  {
    name:"Noroccidente", tone:"#34493f", accent:"#9db07d", symbol:"❦",
    text:"Su posición entre dos mares y su función como corredor ayudan a comprender por qué ha sido escenario de disputas violentas y un espacio relevante en procesos políticos y económicos del país.",
    url:"https://www.comisiondelaverdad.co/noroccidente-capitulo-1"
  }
];

const mount = document.querySelector("#territoryMount");
mount.innerHTML = territories.map((t,i)=>`
<section class="territory" style="--tone:${t.tone};--accent:${t.accent}">
  <div class="territory-bg"></div>
  <div class="territory-copy reveal">
    <div class="num">${String(i+1).padStart(2,"0")}</div>
    <span class="chapter light">EXPEDIENTE TERRITORIAL</span>
    <h2>${t.name}</h2>
    <p>${t.text}</p>
    <a class="source-link" href="${t.url}" target="_blank" rel="noopener noreferrer">Entrar al relato original ↗</a>
  </div>
  <div class="territory-art reveal" aria-hidden="${t.video ? "false":"true"}">
    <div class="orb"></div><div class="ridge"></div><div class="river-mark"></div><div class="symbol">${t.symbol}</div>
    ${t.video ? `<aside class="revelacion">
      <small>REVELACIONES · ABRE OTRA HUELLA</small>
      <h3>${t.video.title}</h3>
      <p>${t.video.desc}</p>
      <button class="watch-btn" data-title="${t.video.title}" data-desc="${t.video.desc}" data-video="${t.video.url}">Ver audiovisual ▶</button>
    </aside>` : `<div class="no-video-note">Sigue el recorrido o entra al relato original para profundizar.</div>`}
  </div>
</section>`).join("");

const reveals = document.querySelectorAll(".reveal");
const revealObs = new IntersectionObserver(entries=>{
  entries.forEach(e=>{ if(e.isIntersecting){e.target.classList.add("visible"); revealObs.unobserve(e.target);} });
},{threshold:.13});
reveals.forEach(el=>revealObs.observe(el));

const dots=[...document.querySelectorAll(".rail-dot")];
const anchors=dots.map(d=>document.querySelector(d.getAttribute("href"))).filter(Boolean);
const navObs=new IntersectionObserver(entries=>{
  entries.forEach(e=>{
    if(e.isIntersecting){
      dots.forEach(d=>d.classList.toggle("active",d.getAttribute("href")==="#"+e.target.id));
    }
  })
},{rootMargin:"-35% 0px -55% 0px"});
anchors.forEach(a=>navObs.observe(a));

const progress=()=> {
  const max=document.documentElement.scrollHeight-innerHeight;
  const p=max>0 ? scrollY/max*100 : 0;
  document.querySelector("#progressBar").style.width=p+"%";
};
addEventListener("scroll",progress,{passive:true}); progress();

const reduced=matchMedia("(prefers-reduced-motion: reduce)").matches;
if(!reduced){
  const pars=[...document.querySelectorAll(".parallax")];
  let ticking=false;
  addEventListener("scroll",()=>{
    if(!ticking){
      requestAnimationFrame(()=>{
        const y=scrollY;
        pars.forEach(el=>el.style.transform=`translate3d(0,${y*Number(el.dataset.speed||0)}px,0)`);
        ticking=false;
      }); ticking=true;
    }
  },{passive:true});
}

const dialog=document.querySelector("#videoDialog");
const player=document.querySelector("#videoPlayer");
document.addEventListener("click",e=>{
  const btn=e.target.closest(".watch-btn");
  if(!btn) return;
  document.querySelector("#videoTitle").textContent=btn.dataset.title;
  document.querySelector("#videoDesc").textContent=btn.dataset.desc;
  player.src=btn.dataset.video;
  document.querySelector("#videoLink").href=btn.dataset.video;
  if(typeof dialog.showModal==="function") dialog.showModal();
  else window.open(btn.dataset.video,"_blank","noopener");
});
const closeDialog=()=>{
  player.pause(); player.removeAttribute("src"); player.load(); dialog.close();
};
document.querySelector(".close-dialog").addEventListener("click",closeDialog);
dialog.addEventListener("click",e=>{if(e.target===dialog) closeDialog();});
