# Colombia adentro · SER FLEX

Micrositio responsive para insertar en Noobe mediante iframe.

## Archivos
- `index.html`
- `styles.css`
- `script.js`
- `assets/mapa-regionalizacion.jpg`

## Publicar en GitHub Pages
1. Crea un repositorio (por ejemplo `colombia-adentro-serflex`).
2. Sube **el contenido de esta carpeta** a la raíz del repositorio.
3. En GitHub: Settings → Pages.
4. En “Build and deployment”, selecciona “Deploy from a branch”.
5. Branch: `main` / folder: `/ (root)`.
6. Guarda. GitHub mostrará la URL pública cuando termine el despliegue.

## Insertar en Noobe
Reemplaza `URL_PUBLICA` por la URL de GitHub Pages:

```html
<div style="position:relative;width:100%;height:min(86vh,820px);min-height:640px;overflow:hidden;border-radius:16px;">
  <iframe
    src="URL_PUBLICA"
    title="Colombia adentro · Explorador territorial"
    loading="lazy"
    allow="fullscreen"
    style="position:absolute;inset:0;width:100%;height:100%;border:0;"
  ></iframe>
</div>
```

Si Noobe limita el alto del iframe, prueba 720–820 px.

## Nota
Los videos y enlaces territoriales apuntan a recursos públicos de la Comisión de la Verdad.
El mapa fue aportado para este recurso y se conserva como imagen local.
